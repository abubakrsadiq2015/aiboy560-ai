# AIBOY560 v2
A polished, original AI-assistant interface with chat history, modes, dark mode, mobile support, and demo responses.
The live AI backend is not included. Never expose a private API key in browser JavaScript.
